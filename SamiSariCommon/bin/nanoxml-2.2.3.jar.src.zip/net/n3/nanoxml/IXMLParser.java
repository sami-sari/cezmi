package net.n3.nanoxml;

public abstract interface IXMLParser
{
  public abstract void setReader(IXMLReader paramIXMLReader);
  
  public abstract IXMLReader getReader();
  
  public abstract void setBuilder(IXMLBuilder paramIXMLBuilder);
  
  public abstract IXMLBuilder getBuilder();
  
  public abstract void setValidator(IXMLValidator paramIXMLValidator);
  
  public abstract IXMLValidator getValidator();
  
  public abstract void setResolver(IXMLEntityResolver paramIXMLEntityResolver);
  
  public abstract IXMLEntityResolver getResolver();
  
  public abstract Object parse()
    throws XMLException;
}


/* Location:              C:\Users\sam\Downloads\nanoxml-2.2.3.jar!\net\n3\nanoxml\IXMLParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */