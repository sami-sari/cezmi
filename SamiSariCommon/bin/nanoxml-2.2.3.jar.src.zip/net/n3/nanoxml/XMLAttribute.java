package net.n3.nanoxml;

class XMLAttribute
{
  private String fullName;
  private String name;
  private String namespace;
  private String value;
  private String type;
  
  XMLAttribute(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    this.fullName = paramString1;
    this.name = paramString2;
    this.namespace = paramString3;
    this.value = paramString4;
    this.type = paramString5;
  }
  
  String getFullName()
  {
    return this.fullName;
  }
  
  String getName()
  {
    return this.name;
  }
  
  String getNamespace()
  {
    return this.namespace;
  }
  
  String getValue()
  {
    return this.value;
  }
  
  void setValue(String paramString)
  {
    this.value = paramString;
  }
  
  String getType()
  {
    return this.type;
  }
}


/* Location:              C:\Users\sam\Downloads\nanoxml-2.2.3.jar!\net\n3\nanoxml\XMLAttribute.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */