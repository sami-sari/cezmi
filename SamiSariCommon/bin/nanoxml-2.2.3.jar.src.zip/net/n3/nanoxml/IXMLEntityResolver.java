package net.n3.nanoxml;

import java.io.Reader;

public abstract interface IXMLEntityResolver
{
  public abstract void addInternalEntity(String paramString1, String paramString2);
  
  public abstract void addExternalEntity(String paramString1, String paramString2, String paramString3);
  
  public abstract Reader getEntity(IXMLReader paramIXMLReader, String paramString)
    throws XMLParseException;
  
  public abstract boolean isExternalEntity(String paramString);
}


/* Location:              C:\Users\sam\Downloads\nanoxml-2.2.3.jar!\net\n3\nanoxml\IXMLEntityResolver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */